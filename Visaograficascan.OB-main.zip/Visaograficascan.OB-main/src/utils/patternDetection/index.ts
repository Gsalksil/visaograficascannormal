// Exemplo de reexportação modular
export * from './trendlines';
export * from './fibonacci';
export * from './candles';
// Adicione outros módulos conforme modularização 