import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { settingsService } from '../settings/settings-service';

// Importando traduções
import ptBR from './locales/pt/translation.json';
import enUS from './locales/en/translation.json';
import esES from './locales/es/translation.json';
import frFR from './locales/fr/translation.json';
import deDE from './locales/de/translation.json';
import itIT from './locales/it/translation.json';
import jaJP from './locales/ja/translation.json';
import koKR from './locales/ko/translation.json';
import zhCN from './locales/zh/translation.json';
import ruRU from './locales/ru/translation.json';

const resources = {
  pt: {
    translation: ptBR
  },
  en: {
    translation: enUS
  },
  es: {
    translation: esES
  },
  fr: {
    translation: frFR
  },
  de: {
    translation: deDE
  },
  it: {
    translation: itIT
  },
  ja: {
    translation: jaJP
  },
  ko: {
    translation: koKR
  },
  zh: {
    translation: zhCN
  },
  ru: {
    translation: ruRU
  }
};

class I18nService {
  private static instance: I18nService;
  private initialized = false;

  private constructor() {
    this.initialize();
  }

  public static getInstance(): I18nService {
    if (!I18nService.instance) {
      I18nService.instance = new I18nService();
    }
    return I18nService.instance;
  }

  private async initialize() {
    if (this.initialized) return;

    const settings = settingsService.getSettings();
    const defaultLanguage = settings?.language || 'pt';

    await i18n
      .use(initReactI18next)
      .init({
        resources,
        lng: defaultLanguage,
        fallbackLng: 'en',
        interpolation: {
          escapeValue: false
        },
        react: {
          useSuspense: false
        }
      });

    this.initialized = true;
  }

  public async changeLanguage(language: string): Promise<void> {
    try {
      await i18n.changeLanguage(language);
      await settingsService.updateSettings({ language });
    } catch (error) {
      console.error('Error changing language:', error);
      throw error;
    }
  }

  public getCurrentLanguage(): string {
    return i18n.language;
  }

  public getAvailableLanguages(): string[] {
    return Object.keys(resources);
  }

  public t(key: string, options?: any): string {
    return i18n.t(key, options);
  }

  public async loadLanguage(language: string): Promise<void> {
    try {
      if (!resources[language]) {
        throw new Error(`Language ${language} not supported`);
      }

      await i18n.loadNamespaces(language);
    } catch (error) {
      console.error(`Error loading language ${language}:`, error);
      throw error;
    }
  }
}

export const i18nService = I18nService.getInstance(); 