import { createClient } from '@supabase/supabase-js';
import { authService } from '../auth/auth-service';

export interface UserSettings {
  theme: 'light' | 'dark' | 'system';
  language: string;
  notifications: boolean;
  defaultTimeframe: string;
  defaultIndicators: string[];
  chartPreferences: {
    showGrid: boolean;
    showVolume: boolean;
    showMA: boolean;
    showBB: boolean;
    showRSI: boolean;
    showMACD: boolean;
    candleStyle: 'candle' | 'line' | 'area';
    colorScheme: 'default' | 'dark' | 'light' | 'custom';
    customColors?: {
      background: string;
      grid: string;
      upCandle: string;
      downCandle: string;
      volume: string;
      indicators: string[];
    };
  };
  analysisPreferences: {
    defaultPatterns: string[];
    defaultTimeframes: string[];
    sensitivity: number;
    autoSave: boolean;
    exportFormat: 'pdf' | 'csv' | 'json';
    includeImage: boolean;
    includePatterns: boolean;
    includeIndicators: boolean;
    includeNotes: boolean;
    includeTags: boolean;
  };
  notificationPreferences: {
    email: boolean;
    push: boolean;
    desktop: boolean;
    sound: boolean;
    alerts: {
      patternDetection: boolean;
      indicatorSignals: boolean;
      priceAlerts: boolean;
      systemUpdates: boolean;
    };
  };
  performancePreferences: {
    maxHistoryItems: number;
    cacheSize: number;
    autoCleanup: boolean;
    compressionLevel: 'none' | 'low' | 'medium' | 'high';
    backgroundProcessing: boolean;
  };
}

export interface SettingsState {
  settings: UserSettings | null;
  isLoading: boolean;
  error: string | null;
}

class SettingsService {
  private static instance: SettingsService;
  private supabase;
  private settings: UserSettings | null = null;
  private listeners: ((state: SettingsState) => void)[] = [];

  private constructor() {
    this.supabase = createClient(
      import.meta.env.VITE_SUPABASE_URL,
      import.meta.env.VITE_SUPABASE_ANON_KEY
    );
    this.initializeSettings();
  }

  public static getInstance(): SettingsService {
    if (!SettingsService.instance) {
      SettingsService.instance = new SettingsService();
    }
    return SettingsService.instance;
  }

  private async initializeSettings() {
    try {
      const user = authService.getCurrentUser();
      if (!user) return;

      const { data, error } = await this.supabase
        .from('user_settings')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error) throw error;

      this.settings = data.settings;

      this.notifyListeners({
        settings: this.settings,
        isLoading: false,
        error: null
      });
    } catch (error: any) {
      this.notifyListeners({
        settings: null,
        isLoading: false,
        error: error.message
      });
    }
  }

  public async updateSettings(updates: Partial<UserSettings>): Promise<UserSettings> {
    try {
      const user = authService.getCurrentUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await this.supabase
        .from('user_settings')
        .update({ settings: { ...this.settings, ...updates } })
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) throw error;

      this.settings = data.settings;

      this.notifyListeners({
        settings: this.settings,
        isLoading: false,
        error: null
      });

      return this.settings;
    } catch (error: any) {
      this.notifyListeners({
        settings: this.settings,
        isLoading: false,
        error: error.message
      });
      throw error;
    }
  }

  public async resetSettings(): Promise<UserSettings> {
    try {
      const user = authService.getCurrentUser();
      if (!user) throw new Error('User not authenticated');

      const defaultSettings: UserSettings = {
        theme: 'system',
        language: 'pt',
        notifications: true,
        defaultTimeframe: '1h',
        defaultIndicators: ['RSI', 'MACD'],
        chartPreferences: {
          showGrid: true,
          showVolume: true,
          showMA: true,
          showBB: true,
          showRSI: true,
          showMACD: true,
          candleStyle: 'candle',
          colorScheme: 'default'
        },
        analysisPreferences: {
          defaultPatterns: ['Doji', 'Hammer', 'Engulfing'],
          defaultTimeframes: ['1h', '4h', '1d'],
          sensitivity: 0.7,
          autoSave: true,
          exportFormat: 'pdf',
          includeImage: true,
          includePatterns: true,
          includeIndicators: true,
          includeNotes: true,
          includeTags: true
        },
        notificationPreferences: {
          email: true,
          push: true,
          desktop: true,
          sound: true,
          alerts: {
            patternDetection: true,
            indicatorSignals: true,
            priceAlerts: true,
            systemUpdates: true
          }
        },
        performancePreferences: {
          maxHistoryItems: 100,
          cacheSize: 50,
          autoCleanup: true,
          compressionLevel: 'medium',
          backgroundProcessing: true
        }
      };

      const { data, error } = await this.supabase
        .from('user_settings')
        .update({ settings: defaultSettings })
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) throw error;

      this.settings = data.settings;

      this.notifyListeners({
        settings: this.settings,
        isLoading: false,
        error: null
      });

      return this.settings;
    } catch (error: any) {
      this.notifyListeners({
        settings: this.settings,
        isLoading: false,
        error: error.message
      });
      throw error;
    }
  }

  public subscribe(listener: (state: SettingsState) => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notifyListeners(state: SettingsState) {
    this.listeners.forEach(listener => listener(state));
  }

  public getSettings(): UserSettings | null {
    return this.settings;
  }

  public getSettingsState(): SettingsState {
    return {
      settings: this.settings,
      isLoading: false,
      error: null
    };
  }
}

export const settingsService = SettingsService.getInstance(); 