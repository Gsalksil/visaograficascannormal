import { RSI, MACD, BollingerBands, Stochastic, ATR, EMA, SMA } from 'technicalindicators';

export interface IndicatorConfig {
  type: string;
  params: Record<string, number>;
}

export interface IndicatorResult {
  values: number[];
  signals: {
    buy: boolean;
    sell: boolean;
    strength: number;
  };
}

export class TechnicalIndicators {
  private static instance: TechnicalIndicators;
  private indicators: Map<string, any>;

  private constructor() {
    this.indicators = new Map();
    this.initializeIndicators();
  }

  public static getInstance(): TechnicalIndicators {
    if (!TechnicalIndicators.instance) {
      TechnicalIndicators.instance = new TechnicalIndicators();
    }
    return TechnicalIndicators.instance;
  }

  private initializeIndicators() {
    // RSI
    this.indicators.set('RSI', {
      calculate: (data: number[], period: number = 14) => {
        const rsi = RSI.calculate({
          values: data,
          period: period
        });
        return this.generateSignals(rsi, 70, 30);
      }
    });

    // MACD
    this.indicators.set('MACD', {
      calculate: (data: number[], fastPeriod: number = 12, slowPeriod: number = 26, signalPeriod: number = 9) => {
        const macd = MACD.calculate({
          values: data,
          fastPeriod,
          slowPeriod,
          signalPeriod,
          SimpleMAOscillator: false,
          SimpleMASignal: false
        });
        return this.generateSignals(macd.map(m => m.MACD), 0, 0);
      }
    });

    // Bollinger Bands
    this.indicators.set('BB', {
      calculate: (data: number[], period: number = 20, stdDev: number = 2) => {
        const bb = BollingerBands.calculate({
          values: data,
          period,
          stdDev
        });
        return this.generateSignals(data, bb.map(b => b.upper), bb.map(b => b.lower));
      }
    });

    // Stochastic
    this.indicators.set('Stochastic', {
      calculate: (high: number[], low: number[], close: number[], period: number = 14, signalPeriod: number = 3) => {
        const stoch = Stochastic.calculate({
          high,
          low,
          close,
          period,
          signalPeriod
        });
        return this.generateSignals(stoch.map(s => s.k), 80, 20);
      }
    });

    // ATR
    this.indicators.set('ATR', {
      calculate: (high: number[], low: number[], close: number[], period: number = 14) => {
        const atr = ATR.calculate({
          high,
          low,
          close,
          period
        });
        return this.generateSignals(atr, 0, 0);
      }
    });

    // EMA
    this.indicators.set('EMA', {
      calculate: (data: number[], period: number = 20) => {
        const ema = EMA.calculate({
          values: data,
          period
        });
        return this.generateSignals(ema, 0, 0);
      }
    });

    // SMA
    this.indicators.set('SMA', {
      calculate: (data: number[], period: number = 20) => {
        const sma = SMA.calculate({
          values: data,
          period
        });
        return this.generateSignals(sma, 0, 0);
      }
    });
  }

  private generateSignals(
    values: number[],
    upperThreshold: number,
    lowerThreshold: number
  ): IndicatorResult {
    const signals = {
      buy: false,
      sell: false,
      strength: 0
    };

    if (values.length < 2) {
      return { values, signals };
    }

    const lastValue = values[values.length - 1];
    const previousValue = values[values.length - 2];

    // Calculate signal strength
    const strength = Math.abs((lastValue - previousValue) / previousValue) * 100;

    // Generate signals based on thresholds
    if (upperThreshold !== 0 && lowerThreshold !== 0) {
      signals.buy = lastValue < lowerThreshold && previousValue >= lowerThreshold;
      signals.sell = lastValue > upperThreshold && previousValue <= upperThreshold;
    } else {
      signals.buy = lastValue > previousValue;
      signals.sell = lastValue < previousValue;
    }

    signals.strength = strength;

    return { values, signals };
  }

  public calculateIndicator(
    type: string,
    data: any,
    params: Record<string, number> = {}
  ): IndicatorResult {
    const indicator = this.indicators.get(type);
    if (!indicator) {
      throw new Error(`Indicator ${type} not found`);
    }

    return indicator.calculate(data, ...Object.values(params));
  }

  public getAvailableIndicators(): string[] {
    return Array.from(this.indicators.keys());
  }
} 