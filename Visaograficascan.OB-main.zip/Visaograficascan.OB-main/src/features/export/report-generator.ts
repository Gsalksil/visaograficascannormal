import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { AnalysisResult } from '../history/analysis-history';
import { authService } from '../auth/auth-service';

export interface ReportOptions {
  format: 'pdf' | 'csv' | 'json';
  includeImage: boolean;
  includePatterns: boolean;
  includeIndicators: boolean;
  includeNotes: boolean;
  includeTags: boolean;
  language: string;
}

export class ReportGenerator {
  private static instance: ReportGenerator;

  private constructor() {}

  public static getInstance(): ReportGenerator {
    if (!ReportGenerator.instance) {
      ReportGenerator.instance = new ReportGenerator();
    }
    return ReportGenerator.instance;
  }

  public async generateReport(
    analysis: AnalysisResult,
    options: ReportOptions
  ): Promise<Blob> {
    switch (options.format) {
      case 'pdf':
        return this.generatePDF(analysis, options);
      case 'csv':
        return this.generateCSV(analysis, options);
      case 'json':
        return this.generateJSON(analysis, options);
      default:
        throw new Error('Unsupported format');
    }
  }

  private async generatePDF(
    analysis: AnalysisResult,
    options: ReportOptions
  ): Promise<Blob> {
    const doc = new jsPDF();
    const user = authService.getCurrentUser();

    // Add header
    doc.setFontSize(20);
    doc.text('Análise Técnica', 20, 20);
    doc.setFontSize(12);
    doc.text(`Data: ${analysis.timestamp.toLocaleDateString()}`, 20, 30);
    doc.text(`Usuário: ${user?.name || 'Anônimo'}`, 20, 40);
    doc.text(`Mercado: ${analysis.marketType}`, 20, 50);
    doc.text(`Timeframe: ${analysis.timeframe}`, 20, 60);

    // Add image if requested
    if (options.includeImage) {
      const img = new Image();
      img.src = analysis.imageData;
      await new Promise(resolve => {
        img.onload = () => {
          const imgWidth = 170;
          const imgHeight = (img.height * imgWidth) / img.width;
          doc.addImage(img, 'PNG', 20, 70, imgWidth, imgHeight);
          resolve(null);
        };
      });
    }

    // Add patterns if requested
    if (options.includePatterns && analysis.patternResults.length > 0) {
      doc.addPage();
      doc.setFontSize(16);
      doc.text('Padrões Detectados', 20, 20);

      const patterns = analysis.patternResults.map(pattern => [
        pattern.pattern,
        pattern.direction,
        `${pattern.confidence}%`,
        pattern.entry.toFixed(2),
        pattern.stopLoss.toFixed(2),
        pattern.takeProfit.toFixed(2)
      ]);

      (doc as any).autoTable({
        startY: 30,
        head: [['Padrão', 'Direção', 'Confiança', 'Entrada', 'Stop Loss', 'Take Profit']],
        body: patterns
      });
    }

    // Add indicators if requested
    if (options.includeIndicators && analysis.indicatorResults.length > 0) {
      doc.addPage();
      doc.setFontSize(16);
      doc.text('Indicadores Técnicos', 20, 20);

      const indicators = analysis.indicatorResults.map(indicator => [
        indicator.name,
        indicator.value.toFixed(2),
        indicator.signal,
        `${indicator.strength}%`
      ]);

      (doc as any).autoTable({
        startY: 30,
        head: [['Indicador', 'Valor', 'Sinal', 'Força']],
        body: indicators
      });
    }

    // Add notes if requested
    if (options.includeNotes && analysis.notes) {
      doc.addPage();
      doc.setFontSize(16);
      doc.text('Notas', 20, 20);
      doc.setFontSize(12);
      doc.text(analysis.notes, 20, 30);
    }

    // Add tags if requested
    if (options.includeTags && analysis.tags.length > 0) {
      doc.setFontSize(12);
      doc.text(`Tags: ${analysis.tags.join(', ')}`, 20, doc.lastAutoTable.finalY + 20);
    }

    return doc.output('blob');
  }

  private generateCSV(
    analysis: AnalysisResult,
    options: ReportOptions
  ): Blob {
    const rows: string[] = [];
    
    // Add header
    rows.push('Data,Usuário,Mercado,Timeframe');
    rows.push(`${analysis.timestamp.toLocaleDateString()},${authService.getCurrentUser()?.name || 'Anônimo'},${analysis.marketType},${analysis.timeframe}`);

    // Add patterns if requested
    if (options.includePatterns && analysis.patternResults.length > 0) {
      rows.push('\nPadrões Detectados');
      rows.push('Padrão,Direção,Confiança,Entrada,Stop Loss,Take Profit');
      analysis.patternResults.forEach(pattern => {
        rows.push(`${pattern.pattern},${pattern.direction},${pattern.confidence},${pattern.entry},${pattern.stopLoss},${pattern.takeProfit}`);
      });
    }

    // Add indicators if requested
    if (options.includeIndicators && analysis.indicatorResults.length > 0) {
      rows.push('\nIndicadores Técnicos');
      rows.push('Indicador,Valor,Sinal,Força');
      analysis.indicatorResults.forEach(indicator => {
        rows.push(`${indicator.name},${indicator.value},${indicator.signal},${indicator.strength}`);
      });
    }

    // Add notes if requested
    if (options.includeNotes && analysis.notes) {
      rows.push('\nNotas');
      rows.push(analysis.notes);
    }

    // Add tags if requested
    if (options.includeTags && analysis.tags.length > 0) {
      rows.push('\nTags');
      rows.push(analysis.tags.join(','));
    }

    return new Blob([rows.join('\n')], { type: 'text/csv' });
  }

  private generateJSON(
    analysis: AnalysisResult,
    options: ReportOptions
  ): Blob {
    const report: any = {
      date: analysis.timestamp.toISOString(),
      user: authService.getCurrentUser()?.name || 'Anônimo',
      market: analysis.marketType,
      timeframe: analysis.timeframe
    };

    if (options.includeImage) {
      report.image = analysis.imageData;
    }

    if (options.includePatterns) {
      report.patterns = analysis.patternResults;
    }

    if (options.includeIndicators) {
      report.indicators = analysis.indicatorResults;
    }

    if (options.includeNotes) {
      report.notes = analysis.notes;
    }

    if (options.includeTags) {
      report.tags = analysis.tags;
    }

    return new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
  }
}

export const reportGenerator = ReportGenerator.getInstance(); 