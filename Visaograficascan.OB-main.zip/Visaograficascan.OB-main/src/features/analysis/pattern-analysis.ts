import { TechnicalIndicators } from '../indicators/technical-indicators';

export interface PatternConfig {
  type: string;
  timeframe: string;
  sensitivity: number;
}

export interface PatternResult {
  pattern: string;
  confidence: number;
  direction: 'bullish' | 'bearish' | 'neutral';
  entry: number;
  stopLoss: number;
  takeProfit: number;
  timeframe: string;
}

export class PatternAnalysis {
  private static instance: PatternAnalysis;
  private indicators: TechnicalIndicators;

  private constructor() {
    this.indicators = TechnicalIndicators.getInstance();
  }

  public static getInstance(): PatternAnalysis {
    if (!PatternAnalysis.instance) {
      PatternAnalysis.instance = new PatternAnalysis();
    }
    return PatternAnalysis.instance;
  }

  public async analyzePattern(
    data: {
      open: number[];
      high: number[];
      low: number[];
      close: number[];
      volume: number[];
    },
    config: PatternConfig
  ): Promise<PatternResult[]> {
    const results: PatternResult[] = [];

    // Análise de Padrões de Candlestick
    const candlePatterns = this.analyzeCandlePatterns(data);
    results.push(...candlePatterns);

    // Análise de Padrões de Chart
    const chartPatterns = this.analyzeChartPatterns(data);
    results.push(...chartPatterns);

    // Análise de Padrões de Fibonacci
    const fibonacciPatterns = this.analyzeFibonacciPatterns(data);
    results.push(...fibonacciPatterns);

    // Análise de Padrões de Harmônicos
    const harmonicPatterns = this.analyzeHarmonicPatterns(data);
    results.push(...harmonicPatterns);

    // Filtra resultados por sensibilidade
    return results.filter(result => result.confidence >= config.sensitivity);
  }

  private analyzeCandlePatterns(data: any): PatternResult[] {
    const patterns: PatternResult[] = [];
    const { open, high, low, close } = data;

    // Doji
    if (this.isDoji(open, close, high, low)) {
      patterns.push({
        pattern: 'Doji',
        confidence: 0.8,
        direction: 'neutral',
        entry: close[close.length - 1],
        stopLoss: low[low.length - 1],
        takeProfit: high[high.length - 1],
        timeframe: 'current'
      });
    }

    // Hammer
    if (this.isHammer(open, close, high, low)) {
      patterns.push({
        pattern: 'Hammer',
        confidence: 0.85,
        direction: 'bullish',
        entry: close[close.length - 1],
        stopLoss: low[low.length - 1],
        takeProfit: close[close.length - 1] + (high[high.length - 1] - low[low.length - 1]),
        timeframe: 'current'
      });
    }

    // Engulfing
    if (this.isEngulfing(open, close)) {
      patterns.push({
        pattern: 'Engulfing',
        confidence: 0.9,
        direction: close[close.length - 1] > open[open.length - 1] ? 'bullish' : 'bearish',
        entry: close[close.length - 1],
        stopLoss: low[low.length - 1],
        takeProfit: high[high.length - 1],
        timeframe: 'current'
      });
    }

    return patterns;
  }

  private analyzeChartPatterns(data: any): PatternResult[] {
    const patterns: PatternResult[] = [];
    const { high, low } = data;

    // Head and Shoulders
    if (this.isHeadAndShoulders(high, low)) {
      patterns.push({
        pattern: 'Head and Shoulders',
        confidence: 0.85,
        direction: 'bearish',
        entry: low[low.length - 1],
        stopLoss: high[high.length - 1],
        takeProfit: low[low.length - 1] - (high[high.length - 1] - low[low.length - 1]),
        timeframe: 'current'
      });
    }

    // Double Top/Bottom
    if (this.isDoubleTop(high) || this.isDoubleBottom(low)) {
      patterns.push({
        pattern: this.isDoubleTop(high) ? 'Double Top' : 'Double Bottom',
        confidence: 0.8,
        direction: this.isDoubleTop(high) ? 'bearish' : 'bullish',
        entry: this.isDoubleTop(high) ? low[low.length - 1] : high[high.length - 1],
        stopLoss: this.isDoubleTop(high) ? high[high.length - 1] : low[low.length - 1],
        takeProfit: this.isDoubleTop(high) 
          ? low[low.length - 1] - (high[high.length - 1] - low[low.length - 1])
          : high[high.length - 1] + (high[high.length - 1] - low[low.length - 1]),
        timeframe: 'current'
      });
    }

    return patterns;
  }

  private analyzeFibonacciPatterns(data: any): PatternResult[] {
    const patterns: PatternResult[] = [];
    const { high, low } = data;

    // Fibonacci Retracement
    const fibLevels = this.calculateFibonacciLevels(high, low);
    if (this.isFibonacciRetracement(fibLevels)) {
      patterns.push({
        pattern: 'Fibonacci Retracement',
        confidence: 0.75,
        direction: 'neutral',
        entry: low[low.length - 1],
        stopLoss: low[low.length - 1] * 0.95,
        takeProfit: high[high.length - 1],
        timeframe: 'current'
      });
    }

    return patterns;
  }

  private analyzeHarmonicPatterns(data: any): PatternResult[] {
    const patterns: PatternResult[] = [];
    const { high, low } = data;

    // Gartley
    if (this.isGartleyPattern(high, low)) {
      patterns.push({
        pattern: 'Gartley',
        confidence: 0.85,
        direction: 'bullish',
        entry: low[low.length - 1],
        stopLoss: low[low.length - 1] * 0.95,
        takeProfit: high[high.length - 1],
        timeframe: 'current'
      });
    }

    // Butterfly
    if (this.isButterflyPattern(high, low)) {
      patterns.push({
        pattern: 'Butterfly',
        confidence: 0.8,
        direction: 'bearish',
        entry: high[high.length - 1],
        stopLoss: high[high.length - 1] * 1.05,
        takeProfit: low[low.length - 1],
        timeframe: 'current'
      });
    }

    return patterns;
  }

  // Helper methods for pattern detection
  private isDoji(open: number[], close: number[], high: number[], low: number[]): boolean {
    const lastIndex = open.length - 1;
    const bodySize = Math.abs(close[lastIndex] - open[lastIndex]);
    const totalSize = high[lastIndex] - low[lastIndex];
    return bodySize <= totalSize * 0.1;
  }

  private isHammer(open: number[], close: number[], high: number[], low: number[]): boolean {
    const lastIndex = open.length - 1;
    const bodySize = Math.abs(close[lastIndex] - open[lastIndex]);
    const lowerShadow = Math.min(open[lastIndex], close[lastIndex]) - low[lastIndex];
    const upperShadow = high[lastIndex] - Math.max(open[lastIndex], close[lastIndex]);
    return lowerShadow > bodySize * 2 && upperShadow < bodySize * 0.1;
  }

  private isEngulfing(open: number[], close: number[]): boolean {
    const lastIndex = open.length - 1;
    const prevIndex = lastIndex - 1;
    if (prevIndex < 0) return false;

    const currentBody = Math.abs(close[lastIndex] - open[lastIndex]);
    const prevBody = Math.abs(close[prevIndex] - open[prevIndex]);
    const isBullish = close[lastIndex] > open[lastIndex] && close[prevIndex] < open[prevIndex];
    const isBearish = close[lastIndex] < open[lastIndex] && close[prevIndex] > open[prevIndex];

    return (isBullish || isBearish) && currentBody > prevBody;
  }

  private isHeadAndShoulders(high: number[], low: number[]): boolean {
    // Implementação simplificada
    return false;
  }

  private isDoubleTop(high: number[]): boolean {
    // Implementação simplificada
    return false;
  }

  private isDoubleBottom(low: number[]): boolean {
    // Implementação simplificada
    return false;
  }

  private calculateFibonacciLevels(high: number[], low: number[]): number[] {
    const lastIndex = high.length - 1;
    const range = high[lastIndex] - low[lastIndex];
    return [
      low[lastIndex],
      low[lastIndex] + range * 0.236,
      low[lastIndex] + range * 0.382,
      low[lastIndex] + range * 0.5,
      low[lastIndex] + range * 0.618,
      low[lastIndex] + range * 0.786,
      high[lastIndex]
    ];
  }

  private isFibonacciRetracement(levels: number[]): boolean {
    // Implementação simplificada
    return false;
  }

  private isGartleyPattern(high: number[], low: number[]): boolean {
    // Implementação simplificada
    return false;
  }

  private isButterflyPattern(high: number[], low: number[]): boolean {
    // Implementação simplificada
    return false;
  }
} 