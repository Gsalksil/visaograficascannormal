import { createClient } from '@supabase/supabase-js';
import { authService } from '../auth/auth-service';

export interface AnalysisResult {
  id: string;
  userId: string;
  timestamp: Date;
  imageData: string;
  patternResults: any[];
  indicatorResults: any[];
  marketType: string;
  timeframe: string;
  notes: string;
  tags: string[];
  isFavorite: boolean;
}

export interface HistoryState {
  analyses: AnalysisResult[];
  isLoading: boolean;
  error: string | null;
}

class AnalysisHistory {
  private static instance: AnalysisHistory;
  private supabase;
  private analyses: AnalysisResult[] = [];
  private listeners: ((state: HistoryState) => void)[] = [];

  private constructor() {
    this.supabase = createClient(
      import.meta.env.VITE_SUPABASE_URL,
      import.meta.env.VITE_SUPABASE_ANON_KEY
    );
    this.initializeHistory();
  }

  public static getInstance(): AnalysisHistory {
    if (!AnalysisHistory.instance) {
      AnalysisHistory.instance = new AnalysisHistory();
    }
    return AnalysisHistory.instance;
  }

  private async initializeHistory() {
    try {
      const user = authService.getCurrentUser();
      if (!user) return;

      const { data, error } = await this.supabase
        .from('analysis_history')
        .select('*')
        .eq('user_id', user.id)
        .order('timestamp', { ascending: false });

      if (error) throw error;

      this.analyses = data.map(item => ({
        ...item,
        timestamp: new Date(item.timestamp)
      }));

      this.notifyListeners({
        analyses: this.analyses,
        isLoading: false,
        error: null
      });
    } catch (error: any) {
      this.notifyListeners({
        analyses: [],
        isLoading: false,
        error: error.message
      });
    }
  }

  public async saveAnalysis(analysis: Omit<AnalysisResult, 'id' | 'userId' | 'timestamp'>): Promise<AnalysisResult> {
    try {
      const user = authService.getCurrentUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await this.supabase
        .from('analysis_history')
        .insert({
          user_id: user.id,
          image_data: analysis.imageData,
          pattern_results: analysis.patternResults,
          indicator_results: analysis.indicatorResults,
          market_type: analysis.marketType,
          timeframe: analysis.timeframe,
          notes: analysis.notes,
          tags: analysis.tags,
          is_favorite: analysis.isFavorite
        })
        .select()
        .single();

      if (error) throw error;

      const newAnalysis: AnalysisResult = {
        ...data,
        timestamp: new Date(data.timestamp)
      };

      this.analyses = [newAnalysis, ...this.analyses];

      this.notifyListeners({
        analyses: this.analyses,
        isLoading: false,
        error: null
      });

      return newAnalysis;
    } catch (error: any) {
      this.notifyListeners({
        analyses: this.analyses,
        isLoading: false,
        error: error.message
      });
      throw error;
    }
  }

  public async updateAnalysis(id: string, updates: Partial<AnalysisResult>): Promise<AnalysisResult> {
    try {
      const user = authService.getCurrentUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await this.supabase
        .from('analysis_history')
        .update(updates)
        .eq('id', id)
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) throw error;

      const updatedAnalysis: AnalysisResult = {
        ...data,
        timestamp: new Date(data.timestamp)
      };

      this.analyses = this.analyses.map(analysis =>
        analysis.id === id ? updatedAnalysis : analysis
      );

      this.notifyListeners({
        analyses: this.analyses,
        isLoading: false,
        error: null
      });

      return updatedAnalysis;
    } catch (error: any) {
      this.notifyListeners({
        analyses: this.analyses,
        isLoading: false,
        error: error.message
      });
      throw error;
    }
  }

  public async deleteAnalysis(id: string): Promise<void> {
    try {
      const user = authService.getCurrentUser();
      if (!user) throw new Error('User not authenticated');

      const { error } = await this.supabase
        .from('analysis_history')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) throw error;

      this.analyses = this.analyses.filter(analysis => analysis.id !== id);

      this.notifyListeners({
        analyses: this.analyses,
        isLoading: false,
        error: null
      });
    } catch (error: any) {
      this.notifyListeners({
        analyses: this.analyses,
        isLoading: false,
        error: error.message
      });
      throw error;
    }
  }

  public async toggleFavorite(id: string): Promise<AnalysisResult> {
    try {
      const analysis = this.analyses.find(a => a.id === id);
      if (!analysis) throw new Error('Analysis not found');

      return await this.updateAnalysis(id, {
        isFavorite: !analysis.isFavorite
      });
    } catch (error: any) {
      this.notifyListeners({
        analyses: this.analyses,
        isLoading: false,
        error: error.message
      });
      throw error;
    }
  }

  public async addTag(id: string, tag: string): Promise<AnalysisResult> {
    try {
      const analysis = this.analyses.find(a => a.id === id);
      if (!analysis) throw new Error('Analysis not found');

      const updatedTags = [...new Set([...analysis.tags, tag])];

      return await this.updateAnalysis(id, {
        tags: updatedTags
      });
    } catch (error: any) {
      this.notifyListeners({
        analyses: this.analyses,
        isLoading: false,
        error: error.message
      });
      throw error;
    }
  }

  public async removeTag(id: string, tag: string): Promise<AnalysisResult> {
    try {
      const analysis = this.analyses.find(a => a.id === id);
      if (!analysis) throw new Error('Analysis not found');

      const updatedTags = analysis.tags.filter(t => t !== tag);

      return await this.updateAnalysis(id, {
        tags: updatedTags
      });
    } catch (error: any) {
      this.notifyListeners({
        analyses: this.analyses,
        isLoading: false,
        error: error.message
      });
      throw error;
    }
  }

  public async searchAnalyses(query: string): Promise<AnalysisResult[]> {
    try {
      const user = authService.getCurrentUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await this.supabase
        .from('analysis_history')
        .select('*')
        .eq('user_id', user.id)
        .or(`notes.ilike.%${query}%,tags.cs.{${query}}`)
        .order('timestamp', { ascending: false });

      if (error) throw error;

      return data.map(item => ({
        ...item,
        timestamp: new Date(item.timestamp)
      }));
    } catch (error: any) {
      this.notifyListeners({
        analyses: this.analyses,
        isLoading: false,
        error: error.message
      });
      throw error;
    }
  }

  public subscribe(listener: (state: HistoryState) => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notifyListeners(state: HistoryState) {
    this.listeners.forEach(listener => listener(state));
  }

  public getAnalyses(): AnalysisResult[] {
    return this.analyses;
  }

  public getHistoryState(): HistoryState {
    return {
      analyses: this.analyses,
      isLoading: false,
      error: null
    };
  }
}

export const analysisHistory = AnalysisHistory.getInstance(); 